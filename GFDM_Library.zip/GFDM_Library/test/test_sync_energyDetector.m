function test_suite = test_sync_energyDetector
    initTestSuite;

    
function test_basic    
p = get_defaultGFDM('SYNC test');
p.B = 20;
p.Bset = [0:1];
sto = 100;
x = circshift(gen_gfdm(p),sto);
[theta, metric] = sync_energyDetector(p, x);
assertElementsAlmostEqual(sto, theta, 'absolute', 10);

