function test_suite = test_sync_CP
    initTestSuite;

function test_basic
display('eabi');
p = get_defaultGFDM('SYNC test');
s = gen_gfdm(p);
chan = 1;
snr = inf;
sto = 100;
N = p.K*p.M;
T = length(s);
cfo = 1/T;
xch = do_channel(s, chan, snr);
r = do_tfshift(xch, sto, cfo);
[theta, epsilon, metric] = sync_CP(p, r);
assertEqual(sto, theta(1));
assertElementsAlmostEqual(cfo, epsilon(1), 'absolute',eps);

function test_fsc
p = get_defaultGFDM('SYNC test');
s = gen_gfdm(p);
chan = get_defaultChannel(p.Ncp,'EXP');
snr = inf;
sto = 100;
N = p.K*p.M;
T = length(s);
cfo = 1/T;
xch = do_channel(s, chan, snr);
r = do_tfshift(xch, sto, cfo);
[theta, epsilon, metric] = sync_CP(p, r);
assertElementsAlmostEqual(sto, theta(1), 'absolute',p.Ncp/2);
assertElementsAlmostEqual(cfo, epsilon(1), 'absolute',epsilon/10);
