% To be ellaborated in future
% test do_modulate/do_demodulate for:
% oQAM = 0/1, all filters (or minimum fd/td for rrc/xia), MF/ZF/MMSE 
clear all;clc;clf

p = get_defaultGFDM('BER');
p.pulse = 'xia1st_fd';
p.a = 0.5;
p.K = 6;
p.Kon = p.K;
p.L = p.K;
p.M = 4;
p.oQAM = 0;
p.mu=2;
%p.Mset = [0];
%p.Kset = [0];
p

d = get_random_symbols(p);
s = do_qammodulate(d, p.mu);
D = do_map(p, s);
g = get_transmitter_pulse(p);
%x = modulate_in_time(p, D, g);
x = do_modulate(p, D);

gr = fft(conj(ifft(get_receiver_pulse(p, 'ZF'))));
G = conj(fft(g));
Df = demodulate_in_frequency(p, G, x);
Dt = demodulate_in_time(p, g, x);
Dh = do_demodulate(p, x, 'MF');

if 1
subplot(3,1,1);plot(real([sqrt(p.K)*g sqrt(p.K)*gr 1/sqrt(p.K)*G]));
subplot(3,1,2);plot(imag([sqrt(p.K)*g sqrt(p.K)*gr 1/sqrt(p.K)*G]));
subplot(3,1,3);plot(D,'o');hold on;plot(Dh);hold off;
end

%Df
%Dt

D
Dh
D-Dh

