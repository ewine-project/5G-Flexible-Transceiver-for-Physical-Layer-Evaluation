% in development, test for metric_correlation
clear all;clc;clf
T = 300;
N = 100;
L = 25;
Y(2:2:N,1) = (sign(randn(N/2,1))+1i*sign(randn(N/2,1)));%wgn(N/2,1,0,'complex');%
y = sqrt(N)*ifft(Y);
z = [y(end-L+(1:L));y;y(1:L)];

snr = inf;
chan = 1;%[1 0 0 0.1 0 0 0.01 ]*wgn(7,1,0,'complex');%get_defaultChannel(L/2, 'HNLOS');%
xch = do_channel([z;sqrt(N)*ifft(wgn(T-N-2*L,1,0,'complex'))], chan, snr);
sto = 100
cfo = rand(1)*N
r = do_tfshift(xch, sto,cfo/N);
metric = metric_correlation(r, y);

[~,locs] = max(abs(metric));
theta = locs-L-1;

[epsilon, I] = cfo_fft_correlation(r(sto+L+(1:N)),y);
epsilon

subplot(2,1,1);plot([real(metric) imag(metric)])
subplot(2,1,2);plot(I)