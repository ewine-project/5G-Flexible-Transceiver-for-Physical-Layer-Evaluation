% Copyright (c) 2017 TU Dresden, Inatel
% All rights reserved.
% See accompanying license.txt for details.
%


% This example shows how the lib can be used to simulate the SER in
% an FSC channel for a MIMO 2x2 or MISO 2x1 system
% Notes: 1) The theoretical SER are still in progress
%        2) The proper channel equalization approach is a open topic to
%        work with

clc; clear; close all;

% Simulation parameters
snr = 10:1:15;          % [dB]
number_errors = 100;    % Minimal number of errors for each SER point.
system = 'MIMO_2x2';
% system = 'MISO_2x1';

% GFDM configuration
p = get_defaultGFDM('BER');
p.pulse = 'rc_fd';
p.a = 0.25;         % Roll-off factor for the RRC and RC filters.
p.K = 128;          % Number of subcarriers.
p.L = p.K;          % Number of overlapping subcarrier for frequency domain GFDM implementation..
p.Kon = p.K;        % Number of actives subcarriers.
p.M = 7;            % Number of subsymbols.
p.mu = 4;           % 16-QAM.

% Channel definition
% h_dB = linspace(0,-10,7).';                         % CH B
% h_dB = [0;-1.5;-1.4;-3.6;-0.6;-9.1;-7;-12;-16.9];   % EVA
h_dB = [0;-1;-2;-3;-8;-17.2;-20.8];                 % EPA
h = 10.^(h_dB/20);


% -------------------------------------------------------------------------
% Theorethical SER
% -------------------------------------------------------------------------
if strcmp(system, 'MIMO_2x2') == true
    Ntx = 2; Nrx = 2;
elseif strcmp(system, 'MISO_2x1') == true
    Ntx = 2; Nrx = 1;
end
v = 1;
SNR = (10.^((min(snr):1:max(snr))/10))';
J = 2^p.mu;       % Number of symbols in the QAM constelattion.
L = sqrt(J);      % Number of projection in each axis of the J-QAM constellation.
Es = 2/3*(J-1);   % Average energy per symbol of the J-QAM constellation.
No = Es./SNR;
sr = 1/sqrt(2);
srt = sqrt(sr^2*sum(h.^2)); 
mu = 4*(L-1)/L;
zfr = get_receiver_pulse(p, 'ZF');
xiu = sum(abs(zfr).^2);
gama = 3*srt^2/(J-1)*SNR/xiu;
u_ala = sqrt(0.5*gama./(1+0.5*gama));
zeta = ((L-1)/L) * ((1-u_ala)/2).^(Ntx*Nrx);
sum_pe = zeros(length(u_ala), 1);
for j = 1:length(u_ala)
    comb = zeros(Ntx*Nrx, 1);
    for i = 0:(Ntx*Nrx)-1
        comb(i+1) = (factorial(Ntx*Nrx-1+i)/( factorial(i)*factorial(Ntx*Nrx-1+i-i)))*((1+u_ala(j))/2)^i;
    end
    sum_pe(j, 1) = sum(comb);
end
pgfdm = 4 * zeta .* sum_pe;


% -------------------------------------------------------------------------
% Simulated SER
% -------------------------------------------------------------------------
A = get_transmitter_matrix(p);
B = get_receiver_matrix(p, 'ZF');
Hall = zeros(p.K*p.M, 1);
Hall(1:length(h), 1) = h;
rcp = (p.M*p.K)/(p.M*p.K+p.Ncp);
SNRvector = snr;

% parfor SNRindex = 1:length(SNRvector)
for SNRindex = 1:length(SNRvector)
    
    ntx = 0;
    SNR = SNRvector(SNRindex);
    fprintf('SNR: %d\n', SNR);
    errors = zeros(1, 1);   % One error counter per user.
    EsN0 = 10^(SNR/10);
    
    while min(errors) < number_errors
        
        % Increments the transmission counter. It will be used to compute the SER.
        ntx = ntx+2;    
   
        % Create symbols
        s1 = get_random_symbols(p);
        s2 = get_random_symbols(p);
               
        % Map them to QAM
        D1 = qammod(s1, 2^p.mu);
        D2 = qammod(s2, 2^p.mu);

        % GFDM modulation
        x11 = A*D1/sqrt(2);     % Signal at TX antenna 1 in the instant t1
        x12 = A*D2/sqrt(2);     % Signal at TX antenna 1 in the instant t2
                
        % Time-Reversal
        x21 = -conj(x12(1+mod(-(0:p.K*p.M-1), p.K*p.M), :));    % Signal at TX antenna 2 in the instant t1
        x22 = +conj(x11(1+mod(-(0:p.K*p.M-1), p.K*p.M), :));    % Signal at TX antenna 2 in the instant t2
        
        % Generate channels
        H11 = fft(Hall.*1/sqrt(2).*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1)));
        H21 = fft(Hall.*1/sqrt(2).*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1)));
        H12 = fft(Hall.*1/sqrt(2).*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1)));
        H22 = fft(Hall.*1/sqrt(2).*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1)));
        
        % STBC Encoder + channel + noise
        sigma = sqrt(1/rcp*Es./(2*EsN0));
        y11 = sum(ifft(fft(x11).*H11), 2) + sum(ifft(fft(x21).*H21), 2) + sigma*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1));
        y21 = sum(ifft(fft(x12).*H11), 2) + sum(ifft(fft(x22).*H21), 2) + sigma*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1));
        y12 = sum(ifft(fft(x11).*H12), 2) + sum(ifft(fft(x21).*H22), 2) + sigma*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1));
        y22 = sum(ifft(fft(x12).*H12), 2) + sum(ifft(fft(x22).*H22), 2) + sigma*(randn(p.K*p.M, 1)+1i*randn(p.K*p.M, 1));
        
        % STBC Decoder and equalization
        if strcmp(system, 'MIMO_2x2') == true
            Heq = abs(H11).^2 + abs(H12).^2 + abs(H21).^2 + abs(H22).^2;
            x1_hat = ifft( ( conj(H11).*fft(y11) + H21.*conj(fft(y21)) + ...
                conj(H12).*fft(y12) + H22.*conj(fft(y22))) ./ Heq );
            x2_hat = ifft( ( conj(H11).*fft(y21) - H21.*conj(fft(y11)) + ...
                conj(H12).*fft(y22) - H22.*conj(fft(y12))) ./ Heq );
        elseif strcmp(system, 'MISO_2x1') == true
            Heq = abs(H11).^2+abs(H21).^2;
            x1_hat = ifft((conj(H11).*fft(y11)+H21.*conj(fft(y21)))./Heq);
            x2_hat = ifft((conj(H11).*fft(y21)-H21.*conj(fft(y11)))./Heq);
        end
        
        % ZF GFDM demodulador
        Data1_hat = sqrt(2)*B*x1_hat;
        Data2_hat = sqrt(2)*B*x2_hat;

        % Demapping the received QAM symbols.
        d1_hat = qamdemod(Data1_hat, 2^p.mu); 
        d2_hat = qamdemod(Data2_hat, 2^p.mu);       
        
        % Error counting
        errors = errors + sum(d1_hat ~= s1) + sum(d2_hat ~= s2);
        
    end
    
    pe(SNRindex,:)=(errors)/(ntx*p.M*p.K);
        
end


% -------------------------------------------------------------------------
% Simulation results
% -------------------------------------------------------------------------
figure
semilogy(min(snr):1:max(snr), pgfdm, 'b')
hold on
semilogy(SNRvector, pe, 'ro')
grid on;
xlabel('SNR (dB)'); ylabel('SER')
legend('Theoretical', 'Simulated')
if strcmp(system, 'MIMO_2x2') == true
    title('MIMO 2x2')
elseif strcmp(system, 'MISO_2x1') == true
    title('MISO 2x1')
end
