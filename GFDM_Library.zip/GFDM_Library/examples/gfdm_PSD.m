% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


% This example shows how a random GFDM signal can be
% created. Additionally the PSD is presented. The theoretical
% PSD is proven to be close to te real obtained PSD

% Nice motivation for a GUI project

%% Create parameter sets for GFDM and OFDM
clear all;clc;
gfdm = get_defaultGFDM('TTI');
gfdm.K = 128;
gfdm.Kon = 75;  % Only allocate some subcarriers
gfdm.pulse = 'rc_fd';
gfdm.a = 0;
gfdm.M = 15;
gfdm.Mon = gfdm.M-2;
gfdm.Ncp = gfdm.K;
gfdm.B = 5; % Number of GFDM blocks to generate
gfdm.Bon = gfdm.B;
gfdm.oQAM = 0;
%% Generate the signals

sGFDM = gen_gfdm(gfdm);
sGFDM_PSD = get_PSD(gfdm);

%% Plot the resulting PSD

% plot time signal
subplot(2,2,1)
hold off
plot([ abs(sGFDM).^2 real(sGFDM) imag(sGFDM) ])
xlim([1 length(sGFDM)]);

% plot CCDF (PAPR)
subplot(2,2,2)
hCCDF = comm.CCDF('AveragePowerOutputPort', true, 'PeakPowerOutputPort', true);
[CCDFy,CCDFx,AvgPwr,PeakPwr] = step(hCCDF,sGFDM);
plot(hCCDF);xlim([0 12])
legend('GFDM PAPR')                     
                     
% plot PSD
subplot(2,1,2)
hold off
segm=gfdm.B;%number of segments for averaging the PSD estimation 
pwelch(2*[sGFDM/std(sGFDM)],blackmanharris(length(sGFDM)/segm));
hold on;
f = linspace(0, 2, length(sGFDM)/segm+1); f = f(1:end-1)';
PSDg=sum(reshape(sGFDM_PSD,segm,[])',2);
%PSDg=sGFDM_PSD(1:segm:end);
PSDg=PSDg/max(PSDg);
plot(f,10*log10(PSDg), 'r');
legend({'simulated GFDM PSD','theoretical GFDM PSD'});
ylim([-80, 10]);