export PATH=/ifn/mns/mamf/maximilian.matthe/bin:$PATH

rm -r ./doc
doxygen && mtocpp_post -q ./html
