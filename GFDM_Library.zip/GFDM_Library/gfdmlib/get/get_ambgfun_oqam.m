% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [Am] = get_ambgfun_oqam(p)
% Return the ambiguity function for the GFDM system considering oqam.
%
% The element (m/2,k/2) of the returned matrix correspond to the
% interference from the GFDM sub-symbol that is k/2 subcarriers and m/2
% sub-symbols away.
nF = p.K;
nT = p.M;
sF = p.M;
sT = p.K;
g00 = get_transmitter_pulse(p);
g00 = g00';

Am = zeros(2*nT, 2*nF);
for tau=0:2*nT-1
    Atf = fft(g00 .* circshift(g00, [0, tau*sT/2]));
    Am(tau+1, :) = Atf(1:sF/2:end);
end
