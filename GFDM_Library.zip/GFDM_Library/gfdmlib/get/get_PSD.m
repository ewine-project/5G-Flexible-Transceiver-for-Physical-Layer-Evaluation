function [PSD IR] = get_PSD(p)
% GET_PSD - Return the PSD (Power Spectral Density) and 
% IR (impulse response) of the given GFDM paramater set.
%
% p = get_defaultGFDM('PSD test');

N = p.M*p.K;
p.Kset = get_kset(p);
p.Mset = get_mset(p);

g = get_transmitter_pulse(p);

% impulse responses
IR = zeros(p.K*p.M+p.Ncp+p.Ncs,length(p.Mset));
for m=1:length(p.Mset)
    IR(:,m) = do_addcp(p,circshift(g, p.Mset(m)*p.K));
end

% subcarrier spectrum
T = p.B*(p.K*p.M+p.Ncp+p.Ncs-p.overlap_blocks);% GFDM stream length
SS = sum(abs(fft(1/sqrt(p.K)*IR,T)).^2,2)/length(p.Mset);

% enabled subcarriers
Kon = zeros(T,1);
t = round(linspace(0,T,p.K+1))+1;
Kon(t(get_kset(p)+1)) = 1;

PSD = abs(ifft(fft(SS).*fft(Kon)));% fast calculation

if p.oQAM==1
    % Use Xia or not?
    useXia = ~isempty(strfind(p.pulse,'xia'));

    % Use reversed pulses or not?
    useReversed = ~isempty(strfind(p.pulse,'_td'));

    if ~isfield(p, 'cache.go')
    if useReversed
        go = g.*exp(1i*2*pi*0.5/p.K*(0:N-1)');
    else
        go = circshift(g, p.K/2);
    end
    else
        go = p.cache.go;
    end

    % impulse responses
    IRo = zeros(p.K*p.M+p.Ncp+p.Ncs,length(p.Mset));
    for m=1:length(p.Mset)
        IRo(:,m) = do_addcp(p,circshift(go, p.Mset(m)*p.K));
    end

    % subcarrier spectrum
    SSo = sum(abs(fft(1/sqrt(p.K)*IRo,T)).^2,2)/length(p.Mset);

    PSD = (PSD + abs(ifft(fft(SSo).*fft(Kon))))/2;% fast calculation

end
