% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function Dhat = demodulate_in_time(p, g, x)
% important : g is the transmitter pulse!
K = p.K; M = p.M;
N = M*K;

Dhat = zeros(K, M);
 
for m=1:M
    symbol = circshift(x,-K*(m-1));
	symbolMatched = symbol .* conj(g);
    temp = reshape(symbolMatched,K,M);
 	dhat = fft(sum(temp,2));
    Dhat(:,m) = dhat;
 	
end
