% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%

function Dhat = do_demodulate(p, x, recType)
% Demodulate a GFDM signal
%
% \param recType can be
%    - MF: matched filter demodulation
%    - ZF: zero forcing demodulation (default)
%    - MMSE: mmse demodulation
%    .
%    both receiver types are implemented in the frequency domain
% \param x the signal to demodulate
%
%
oQAM = p.oQAM;
if p.K>16 || (p.K/16-floor(p.K/16))>0
    L = p.K;
else
    L = 16;
end

if ~oQAM
    if nargin == 2 || strcmp(recType, 'ZF')
        g = get_receiver_pulse(p, 'ZF');
    elseif strcmp(recType, 'MF')
        g = get_transmitter_pulse(p);
    elseif strcmp(recType, 'MMSE')
        g = get_receiver_pulse(p, 'MMSE');
    else
        error('Receiver Type not implemented!');
    end
    Dhat = demodulate_in_time(p, g, x);
else
    Dhat = demodulate_oqam(p, x);
end


