% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function r = do_tfshift(xch, sto, cfo)
% Apply circular integer symbol time offset (STO) and normalized
% carrier frequency offset (CFO) to a signal xch
%
% \param xch the signal (column vector) that is shifted
% \param impResponse impulse response if the channel, sampled at
%                    the system frequency. The resulting signal is
%                    calculated by circular convolution of x with
%                    the CIR.
% \param sto is the circular time offset in integer samples
% \param cfo is the frequency shift: exp(1i*2*pi*epsilon*(0:length(x)-1)').

assert(all(size(sto) == [1,1]));
assert(all(size(cfo) == [1,1]));
assert(size(xch,2) == 1);

r = circshift(xch,sto);
r = r.*exp(1i*2*pi*cfo*(0:length(xch)-1)');