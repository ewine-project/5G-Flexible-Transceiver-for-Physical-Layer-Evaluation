% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [ d s D ] = gen_data( p )
% generates a complex data input stream, returning the integer data signal 
% and the mapped data source in a 3D structure:
% [rows = subcarriers, column = subsymbols, block index] 

bset = get_bset(p)+1;

do = zeros(length(get_mset(p)) * length(get_kset(p)),length(get_bset(p)));

for j=1:length(bset)

    do(:,j) = get_random_symbols(p);
    s = do_qammodulate(do(:,j), p.mu);
    D = do_map(p, s);

end

end


