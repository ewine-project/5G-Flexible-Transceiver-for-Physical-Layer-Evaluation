% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [sto, metric, criterion] = sync_energyDetector(p, x)
% Basic estimates of symbol timing offset (STO) using energy detection


T = length(x);
N = p.K*p.M+p.Ncp+p.Ncs; % GFDM block length
metric = metric_energyDetector(N, x);
[~, locs] = max(metric);
sto = mod(locs-1,T);