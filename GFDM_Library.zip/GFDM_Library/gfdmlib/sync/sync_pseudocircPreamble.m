% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [sto, cfo, metric] = sync_pseudocircPreamble(p, x, display)
% Estimates symbol timing offset (STO) and carrier frequency offset CFO
% based on pseudo circular preamble