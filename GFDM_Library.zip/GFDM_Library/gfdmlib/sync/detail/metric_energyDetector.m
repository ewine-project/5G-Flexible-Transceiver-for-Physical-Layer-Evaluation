% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function metric = metric_energyDetector(N, x)
% Returns a metric that measures the circular difference of the energy
% of two successive sliding windows with length N each.

T=length(x);
metric = zeros(T,1);
for n=1:T,
    k0=mod(n+(0:N-1)-1-N,T)+1;
    k1=mod(k0+N-1,T)+1;
    %sliding window metric
    metric(n,1)=sum(abs(x(k1)).^2)-sum(abs(x(k0)).^2);
end