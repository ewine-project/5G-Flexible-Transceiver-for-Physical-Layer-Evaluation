% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function metric = metric_correlation(x, y)
% Returns a metric that measures the normalized correlation of the unkown
% signal x and the known signal y


T=length(x);
metric = zeros(T,1);
N = length(y);
for n=1:T,
    k=mod(n+(0:N-1)-1,T)+1;
    %sliding window metric
    metric(n,1)=x(k)'*y;
end
metric = metric/(y'*y);