% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function metric = metric_autocorrelation(L, N, x)
% Returns a metric that measures the normalized autocorrelation of two
% successive sliding windows, apart from N samples, with length L each.


T=length(x);
metric = zeros(T,1);
for n=1:T,
    k0=mod(n+(0:L-1)-1,T)+1;
    k1=mod(k0+N-1,T)+1;
    %sliding window metric
    metric(n,1)=x(k0)'*x(k1)/(1/2*x(k0)'*x(k0) + 1/2*x(k1)'*x(k1)+eps);
end