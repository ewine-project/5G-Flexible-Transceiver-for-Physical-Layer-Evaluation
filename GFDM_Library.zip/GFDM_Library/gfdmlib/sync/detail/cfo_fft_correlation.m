% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [epsilon, I] = cfo_fft_correlation(a, b)
% Returns the CFO(carrier frequency offset) estimation based on the FFT of 
% the correlation of the signal 'a' and the known signal 'b'.
% See paper: "An Efficient Frequency Offset Estimation Method With a Large
% Range for Wireless OFDM Systems"

N=length(a);
c=a.*conj(b);
I=abs(fft(c)/N).^2;
[peak vi]=max(I);
vi=vi-1;

%fractional value 1st iteraction
Iup=abs(c'*exp(1i*2*pi*(vi+.5)/N*(0:N-1)'));
Idw=abs(c'*exp(1i*2*pi*(vi-.5)/N*(0:N-1)'));
vf1=(Iup-Idw)/(2*(Iup+Idw));

%fractional value 2nd iteraction
Iup=abs(c'*exp(1i*2*pi*(vi+vf1+.5)/N*(0:N-1)'));
Idw=abs(c'*exp(1i*2*pi*(vi+vf1-.5)/N*(0:N-1)'));
vf2=vf1+(Iup-Idw)/(2*(Iup+Idw));

epsilon=vi+vf2;