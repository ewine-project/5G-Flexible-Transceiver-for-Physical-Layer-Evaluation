% Copyright (c) 2014 TU Dresden
% All rights reserved.
% See accompanying license.txt for details.
%


function [sto, cfo, metric] = sync_CP(p, x)
% Estimates symbol timing offset (STO) and carrier frequency offset CFO
% based on cyclic prefix/suffix metric

L = p.Ncp+p.Ncs;
N = p.M*p.K;
metric = metric_autocorrelation(L, N, x);

% split the metrics according to the GFDM block length
metrics = do_split(p, metric);

[~, peaks] = max(abs(metrics));

peaks = peaks+(0:p.B-1)*(p.Ncp+p.Ncs+p.M*p.K-p.overlap_blocks);

sto = peaks - 1;
cfo = angle(metric(peaks))/(2*pi*N);